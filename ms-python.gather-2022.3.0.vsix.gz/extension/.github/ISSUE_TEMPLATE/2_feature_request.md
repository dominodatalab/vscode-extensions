---
name: General feature request
about: Suggest an idea for this project
labels: enhancement
---

<!-- Please search existing issues to avoid creating duplicates. -->

<!-- Describe the feature you'd like. -->
